package com.acuant.acuantmobilesdk.internal;

import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Environment;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ZMiniCard {
    public enum CardType {
        id,
        passport,
    }

    public ZMiniCard() {
        n_create();
    }
    public void		create() {
        n_create();
    }
    public void		release(){
        n_release();
    }
    public  int		detectDocument(Bitmap bitmap){
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int size = width * height;

        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        return n_detectBuffer(pixels, width, height);
    }
    public CardType getCardType() {
        int type = n_getCardType();
        if (type == 0) return CardType.id;
        else return CardType.passport;
    }
    public  Point[]		getDocumentRegion(){
        int[] region = n_getRegion();
        Point[] points = new Point[4];
        for (int i=0; i<4; i++) {
            points[i] = new Point(region[i*2], region[i*2+1]);
        }
        return points;
    }
    public Bitmap	cropDocument(Bitmap bitmap, Point[] points, int crop_width)
    {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int size = width * height;

        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        int[] pts_int = new int[8];
        for (int i=0; i<4; i++) {
            pts_int[i * 2] = points[i].x;
            pts_int[i * 2 + 1] = points[i].y;
        }
        int[] cropped = n_cropImage(pixels, width, height, pts_int, crop_width);
        int cropped_width = n_getCropWidth();
        int cropped_height = n_getCropHeight();

        Bitmap retBmp = Bitmap.createBitmap(cropped, cropped_width, cropped_height, Bitmap.Config.ARGB_8888);
        return retBmp;
    }
    byte[] toBytes(int i)
    {
        byte[] result = new byte[4];

        result[3] = (byte) (i >> 24);
        result[2] = (byte) (i >> 16);
        result[1] = (byte) (i >> 8);
        result[0] = (byte) (i /*>> 0*/);

        return result;
    }
    public void saveBitmap2Mat(Bitmap bitmap, String filename)
    {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int size = width * height;

        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        byte[] buffer = n_getImageFromBitmap(pixels, width, height);

        File file = new File(filename);
        try {
            //DataOutputStream dos = new DataOutputStream(file);
            FileOutputStream f = new FileOutputStream(file);
            f.write(toBytes(height));
            f.write(toBytes(width));
            int type = 17;
            f.write(toBytes(type));
            f.write(buffer);
            f.flush();
            f.close();
        }
        catch(NullPointerException e)
        {

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public byte[] convertJ2KToJPG(byte[] buffer)
    {
        return n_convertJ2KToJPG(buffer, buffer.length);
    }

    private native void		n_create();
    private native void		n_release();
    private native int		n_detectBuffer(int[] buffer, int width,  int height);
    private native int		n_getCardType();
    private native int[]     n_getRegion();
    private native int[]	n_cropImage(int[] buffer, int width,  int height, int[] points, int crop_width);
    private native int		n_getCropHeight();
    private native int		n_getCropWidth();
    private native byte[]   n_getImageFromBitmap(int[] buffer, int width,  int height);
    private native byte[]   n_convertJ2KToJPG(byte[] buffer, int width);

    static {
        try {
            System.loadLibrary("zminicard");
        }
        catch(Exception e){
            e.getMessage();
        }
    }
}
