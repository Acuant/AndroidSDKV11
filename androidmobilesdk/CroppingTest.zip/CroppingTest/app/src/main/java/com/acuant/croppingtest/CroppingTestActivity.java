package com.acuant.croppingtest;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.acuant.acuantmobilesdk.internal.ZMiniCard;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CroppingTestActivity extends AppCompatActivity {

    final private static String test_path = Environment.getExternalStorageDirectory().toString()+"/CroppingTest/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cropping_test);
        TextView messageTextView = findViewById(R.id.message);
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        0);

            }
        } else {
            messageTextView.setText("Test in progress...");
            testCropping();
            messageTextView.setText("Test in finished");

        }

    }

    private void testCropping(){
        String SD_CARD_PATH = test_path;
        List<File> files = getListFiles(new File(SD_CARD_PATH));
        ZMiniCard minicard = new ZMiniCard();
        for(int i=0;i<files.size();i++){
            String imageName = files.get(i).getName();
            if(!imageName.toLowerCase().contains(".jpg")
                    && !imageName.toLowerCase().contains(".png")
                    && !imageName.toLowerCase().contains(".jpeg")){
                continue;
            }
            String photoPath = files.get(i).getAbsolutePath();
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bitmap = BitmapFactory.decodeFile(photoPath, options);
            if(bitmap==null){
                continue;
            }

            boolean fprocess = false;
            Point[] points = new Point[4];
            ZMiniCard.CardType cardType = ZMiniCard.CardType.id;
            int img_width= bitmap.getWidth();
            int img_height = bitmap.getHeight();
                if (minicard.detectDocument(bitmap) == 1) {
                    points = minicard.getDocumentRegion();
                    ZMiniCard.CardType t = minicard.getCardType();
                    cardType = minicard.getCardType();
                    fprocess = true;
                }


            if (fprocess == true)
            {
                Log.d("TAG","detected i="+i);
                if(cardType==ZMiniCard.CardType.id && files.get(i).getAbsolutePath().toLowerCase().contains("passport")){
                    Log.d("TAG","could not detect correctly i="+i);
                    saveBitmap(bitmap,"passport_but_detected_id/"+imageName);
                }else if(cardType==ZMiniCard.CardType.passport && !files.get(i).getAbsolutePath().toLowerCase().contains("passport")){
                    Log.d("TAG","could not detect correctly i="+i);
                    saveBitmap(bitmap,"id_but_detected_passport/"+imageName);
                }else{
                    Bitmap croppedBitmap = minicard.cropDocument(bitmap, points,2024);
                    float longSide = (float) Math.max(croppedBitmap.getWidth(),croppedBitmap.getHeight());
                    float shortSide = (float) Math.min(croppedBitmap.getWidth(),croppedBitmap.getHeight());
                    float aspectRatio = longSide/shortSide;
                    if(minicard.getCardType()==ZMiniCard.CardType.id &&  (aspectRatio<0.97*1.58870 || aspectRatio>1.03*1.58870)){
                        //saveBitmap(croppedBitmap,"badCroppedId/"+"Aspect_"+aspectRatio+"_"+imageName);
                        saveBitmap(croppedBitmap,"badCroppedId/"+imageName);
                        saveBitmap(bitmap,"badCroppedId/original/"+imageName);
                    }else if(minicard.getCardType()==ZMiniCard.CardType.passport &&  (aspectRatio<0.97*1.42 || aspectRatio>1.03*1.42)){
                        //saveBitmap(croppedBitmap,"badCroppedPassport/"+"Aspect_"+aspectRatio+"_"+imageName);
                        saveBitmap(croppedBitmap,"badCroppedPassport/"+imageName);
                        saveBitmap(bitmap,"badCroppedPassport/original/"+imageName);
                    }else {
                        saveBitmap(croppedBitmap, "success/" + imageName);
                    }
                }
            }else{
                Log.d("TAG","could not detect i="+i);
                saveBitmap(bitmap,"could_not_detect/"+imageName);

            }

        }
        minicard.release();
    }

    private List<File> getListFiles(File parentDir) {
        ArrayList<File> inFiles = new ArrayList<File>();
        File[] files = parentDir.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                inFiles.addAll(getListFiles(file));
            } else {
                if(file.getName().toLowerCase().endsWith(".jpg") ||
                        file.getName().toLowerCase().endsWith(".jpeg") ||
                        file.getName().toLowerCase().endsWith(".png")){
                    inFiles.add(file);
                }
            }
        }
        return inFiles;
    }

    private boolean saveBitmap(Bitmap bitmap, String name) {
        if (bitmap != null) {
            File file = new File(test_path+"Output/" + name);
            if(!file.getParentFile().exists()){
                file.getParentFile().mkdirs();
            }
            FileOutputStream fOutputStream = null;

            try {
                fOutputStream = new FileOutputStream(file);

                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOutputStream);

                fOutputStream.flush();
                fOutputStream.close();

                MediaStore.Images.Media.insertImage(this.getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
            } catch (FileNotFoundException e) {
                return false;
            } catch (IOException e) {
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    /** Get left value of the bounding rectangle of the given points. */
    static float getRectLeft(float[] points) {
        return Math.min(Math.min(Math.min(points[0], points[2]), points[4]), points[6]);
    }

    /** Get top value of the bounding rectangle of the given points. */
    static float getRectTop(float[] points) {
        return Math.min(Math.min(Math.min(points[1], points[3]), points[5]), points[7]);
    }

    /** Get right value of the bounding rectangle of the given points. */
    static float getRectRight(float[] points) {
        return Math.max(Math.max(Math.max(points[0], points[2]), points[4]), points[6]);
    }

    /** Get bottom value of the bounding rectangle of the given points. */
    static float getRectBottom(float[] points) {
        return Math.max(Math.max(Math.max(points[1], points[3]), points[5]), points[7]);
    }

    /** Get width of the bounding rectangle of the given points. */
    static float getRectWidth(float[] points) {
        return getRectRight(points) - getRectLeft(points);
    }

    /** Get height of the bounding rectangle of the given points. */
    static float getRectHeight(float[] points) {
        return getRectBottom(points) - getRectTop(points);
    }

    /** Get horizontal center value of the bounding rectangle of the given points. */
    static float getRectCenterX(float[] points) {
        return (getRectRight(points) + getRectLeft(points)) / 2f;
    }

    /** Get vertical center value of the bounding rectangle of the given points. */
    static float getRectCenterY(float[] points) {
        return (getRectBottom(points) + getRectTop(points)) / 2f;
    }

    static Rect getRectFromPoints(
            float[] points,
            int imageWidth,
            int imageHeight) {
        int left = Math.round(Math.max(0, getRectLeft(points)));
        int top = Math.round(Math.max(0, getRectTop(points)));
        int right = Math.round(Math.min(imageWidth, getRectRight(points)));
        int bottom = Math.round(Math.min(imageHeight, getRectBottom(points)));

        Rect rect = new Rect(left, top, right, bottom);
        return rect;
    }

    public static Bitmap cornerPin(Bitmap b, float[] srcPoints, float[] dstPoints) {
        int w = b.getWidth(), h = b.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Canvas c = new Canvas(result);
        Matrix m = new Matrix();
        m.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4);
        c.drawBitmap(b, m, p);
        return result;
    }

    public static Bitmap perspectiveCorrection(Bitmap bitmap){
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        float[] src = {0, 0, 0, h, w, h, w, 0};
        float[] dst = {0, 0, 0, h, w, 0.8f * h, w, 0.2f * h};
        Bitmap transformed = cornerPin(bitmap, src, dst);
        return transformed;
    }

}
